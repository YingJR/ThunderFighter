cc.Class({
    extends: cc.Component,

    properties: {

        id: 0,
        
        //移動速度
        velocity: 2,
    
        //最大炸彈數量
        bombsMax: 1,
    
        ///炸彈爆炸威力
        bombStrength: 1,
    
        //實體在Map的點位
        position: {},
    
        //圖片尺寸
        size: {
            w: 48,
            h: 48
        },
    
        //Bitmap animation
        bmp: null,
    
        alive: true,
    
        bombs: [],
    
        controls: {
            'up': 'up',
            'left': 'left',
            'down': 'down',
            'right': 'right',
            'bomb': 'bomb'
        },
    
        /**
         * Bomb that player can escape from even when there is a collision
         */
        escapeBomb: null,
    
        deadTimer: 0,
    
    },

    // use this for initialization
    onLoad: function () {
        this.setInputControl();
    },

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
    update: function (dt) {
        if (!this.alive) {
                return;
        }
        
        

    },
    
setInputControl: function () {
        var self = this;
        //add keyboard input listener to jump, turnLeft and turnRight
        cc.eventManager.addListener({
            event: cc.EventListener.KEYBOARD,
            // set a flag when key pressed
            onKeyPressed: function(keyCode, event) {
                switch(keyCode) {
                    case cc.KEY.a:
                    case cc.KEY.left:
                        self.accLeft = true;
                        self.accRight = false;
                        
                        alert("123");
                        break;
                    case cc.KEY.d:
                    case cc.KEY.right:
                        self.accLeft = false;
                        self.accRight = true;
                        break;
                }
            },
            // unset a flag when key released
            onKeyReleased: function(keyCode, event) {
                switch(keyCode) {
                    case cc.KEY.a:
                    case cc.KEY.left:
                        self.accLeft = false;
                        break;
                    case cc.KEY.d:
                    case cc.KEY.right:
                        self.accRight = false;
                        break;
                }
            }
        }, self.node);
    },
    
    
});
